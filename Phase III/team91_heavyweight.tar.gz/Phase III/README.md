## Phase III
__Score: ??/100__

1. A cover page
    <br/>same as Phase 1 and Phase 2.
2. A text file with all SQL statements for each task. 
    <br/>(Follow the template in the Phase 2 design methodology).
    <br/>NOTE: A set of SQL statements may be required in order to complete one task. However, in such cases, the last SQL statement should show the output according to the specification. Views and nested queries may be used to support the tasks.
3. For the heavy weight project option, your source code for the application.